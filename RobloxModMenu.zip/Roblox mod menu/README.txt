Hello, i'm 2xx013 and my dream is to become an programist, this is one of my first programs which i will publish, i hope you'll like it
2xx013..